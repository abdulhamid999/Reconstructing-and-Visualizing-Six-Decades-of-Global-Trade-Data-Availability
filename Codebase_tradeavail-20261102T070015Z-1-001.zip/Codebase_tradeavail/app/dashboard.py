"""Interactive dashboard for the cleaned Comtrade availability table.

Run:  streamlit run app/dashboard.py
Data: reads ../data/comtrade_availability_clean.csv (or outputs/...), or upload the cleaned CSV in the sidebar.
"""
import os, sys
import numpy as np
import pandas as pd
import streamlit as st

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
from tradeavail.oml_omh import plot_oml, plot_omh  # noqa: E402

st.set_page_config(page_title="Comtrade availability", layout="wide")
CANDIDATES = [os.path.join(HERE, "..", "data", "comtrade_availability_clean.csv"),
              os.path.join(HERE, "..", "outputs", "comtrade_availability_clean.csv")]


@st.cache_data
def load(path_or_file):
    return pd.read_csv(path_or_file, encoding="utf-8-sig", dtype={"reporters": str}, parse_dates=["lastReleased_date"])


st.title("Global trade-data availability, 1962-2025")
st.caption("UN Comtrade Data Availability export (cleaned). Metadata only: no trade values.")
up = st.sidebar.file_uploader("Cleaned CSV (optional)", type="csv")
path = next((p for p in CANDIDATES if os.path.exists(p)), None)
if up is None and path is None:
    st.info("Upload comtrade_availability_clean.csv in the sidebar, or place it in data/."); st.stop()
df = load(up if up is not None else path)

yr = st.sidebar.slider("Reference years", int(df.period.min()), int(df.period.max()), (1988, int(df.period.max())))
cls = st.sidebar.multiselect("Classification", sorted(df.classificationCode.unique()), default=sorted(df.classificationCode.unique()))
rep = st.sidebar.multiselect("Reporters (empty = all)", sorted(df.reporterDesc.unique()))
f = df[df.period.between(*yr) & df.classificationCode.isin(cls)]
if rep:
    f = f[f.reporterDesc.isin(rep)]
if f.empty:
    st.warning("No records match the filters."); st.stop()

lag = f.publication_lag_years.dropna()
c = st.columns(4)
c[0].metric("Records", f"{len(f):,}"); c[1].metric("Reporters", f"{f.reporterDesc.nunique():,}")
c[2].metric("Median lag (years)", f"{lag.median():.1f}" if len(lag) else "n/a", help="Lag to the LATEST release; recent years are right-censored.")
c[3].metric("Mean file size (MB)", f"{f.fileSize_MB.mean():.1f}", help=f"SD {f.fileSize_MB.std():.1f} MB (right-skewed)")

t1, t2, t3, t4 = st.tabs(["Classification regimes", "Volume and file size", "Publication lag", "Data"])
with t1:
    st.subheader("Records per year by classification")
    st.area_chart(f.groupby(["period", "classificationCode"]).size().unstack(fill_value=0))
with t2:
    yearly = f.dropna(subset=["totalRecords"]).groupby("period").totalRecords.sum()
    a, b = st.columns(2)
    a.subheader("Mean file size per year (MB)"); a.line_chart(f.groupby("period").fileSize_MB.mean())
    d = f.dropna(subset=["totalRecords"]); d = d[d.totalRecords > 0]
    b.subheader("Bytes per record (median)"); b.line_chart((d.fileSize_MB * 1024 ** 2 / d.totalRecords).groupby(d.period).median())
    if len(yearly) >= 2 and (yearly > 0).all():
        st.subheader("Total records per year, order-of-magnitude charts")
        kind = st.radio("Chart", ["OML (line)", "OMH (horizon)"], horizontal=True)
        import matplotlib.pyplot as plt
        if kind.startswith("OML"):
            fig, ax = plt.subplots(figsize=(10, 4)); plot_oml(yearly.index.to_numpy(), yearly.to_numpy(), ax=ax)
        else:
            fig = plot_omh(yearly.index.to_numpy(), yearly.to_numpy())
        st.pyplot(fig)
        st.caption("A linear mantissa scale mutes growth inside the top band; choose the chart by the question.")
with t3:
    st.subheader("Distribution of lag (0-20 years)")
    l = lag[(lag >= 0) & (lag <= 20)]
    st.bar_chart(l.value_counts().sort_index())
    st.caption(f"{len(l):,} records with a defined lag in range; SD {l.std():.1f} years. Do not read a trend from lag vs year without adjusting for exposure.")
with t4:
    st.dataframe(f, use_container_width=True, height=420)
    st.download_button("Download filtered CSV", f.to_csv(index=False).encode("utf-8-sig"), "comtrade_filtered.csv", "text/csv")
