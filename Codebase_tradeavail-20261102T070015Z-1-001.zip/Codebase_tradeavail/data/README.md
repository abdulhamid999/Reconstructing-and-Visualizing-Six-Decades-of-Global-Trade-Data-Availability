# data/

Place the raw UN Comtrade Data Availability export here as `trade_data_availability.csv`
(Latin-1 encoded, ragged rows). Raw and cleaned CSVs are git-ignored by default.
Source: UN Comtrade, https://comtradeplus.un.org/ (export retrieved 21 Sep 2026).
