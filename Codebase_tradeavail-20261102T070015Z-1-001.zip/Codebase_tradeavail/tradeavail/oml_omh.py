"""Order-of-Magnitude Line (OML) and Horizon (OMH) charts (after Braun et al., IEEE TVCG 2023).

v = m * 10**e with 1 <= m < 10;  y = (e - e_min) + (m - 1) / 9.
"""
import numpy as np
import matplotlib.pyplot as plt


def mantissa_exponent(values):
    values = np.asarray(values, dtype=float)
    if (values <= 0).any():
        raise ValueError("OML/OMH require strictly positive values")
    exponents = np.floor(np.log10(values)).astype(int)
    return values / (10.0 ** exponents), exponents


def oml_positions(values):
    """Return (mantissas, exponents, y_pos, e_min, e_max)."""
    m, e = mantissa_exponent(values)
    e_min, e_max = int(e.min()), int(e.max())
    return m, e, (e - e_min) + (m - 1) / 9.0, e_min, e_max


def plot_oml(years, values, title="Order-of-Magnitude Line (OML) Chart", ylabel="Value (order of magnitude)", ax=None):
    years = np.asarray(years)
    m, e, y, e_min, e_max = oml_positions(values)
    n = e_max - e_min + 1
    cmap = plt.get_cmap("plasma")
    colors = [cmap((k - e_min) / max(1, n - 1)) for k in range(e_min, e_max + 1)]
    if ax is None:
        _, ax = plt.subplots(figsize=(12, 6))
    for i in range(len(years) - 1):
        c = colors[e[i] - e_min]
        ax.plot(years[i:i + 2], y[i:i + 2], color=c, linewidth=2, zorder=3)
        ax.fill_between(years[i:i + 2], y[i:i + 2], 0, color=c, alpha=0.35, zorder=1)
    ax.scatter(years, y, c=[colors[k - e_min] for k in e], s=18, zorder=4, edgecolor="white", linewidth=0.4)
    for b in range(n + 1):
        ax.axhline(b, color="grey", linewidth=0.8, alpha=0.6, zorder=0)
    for b in range(n):
        ax.axhline(b + 4 / 9.0, color="grey", linewidth=0.4, alpha=0.35, zorder=0, linestyle="--")
    ax.set_yticks(range(n + 1))
    ax.set_yticklabels([f"$10^{{{k}}}$" for k in range(e_min, e_max + 2)])
    ax.set_xlabel("Year"); ax.set_ylabel(ylabel); ax.set_title(title)
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(e_min, e_max))
    plt.colorbar(sm, ax=ax, pad=0.02).set_label("Order of magnitude (exponent e)")
    return ax


def plot_omh(years, values, title="Order-of-Magnitude Horizon (OMH) Graph"):
    years = np.asarray(years)
    m, e, _, e_min, e_max = oml_positions(values)
    n = e_max - e_min + 1
    cmap = plt.get_cmap("plasma")
    fig, axes = plt.subplots(n, 1, figsize=(12, 1.15 * n), sharex=True, squeeze=False)
    axes = axes[:, 0]
    for idx, k in enumerate(range(e_max, e_min - 1, -1)):  # largest band on top
        ax = axes[idx]
        vals = np.where(e == k, (m - 1) / 9.0, np.nan)
        c = cmap((k - e_min) / max(1, n - 1))
        ax.fill_between(years, 0, vals, color=c, alpha=0.85, linewidth=0)
        ax.plot(years, vals, color=c, linewidth=1.2)
        ax.set_ylim(0, 1); ax.set_yticks([0, 1]); ax.set_yticklabels(["", ""])
        ax.set_ylabel(f"$10^{{{k}}}$", rotation=0, labelpad=25, va="center", fontsize=10, fontweight="bold")
        ax.grid(axis="x", alpha=0.2)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
    axes[-1].set_xlabel("Year")
    fig.suptitle(title, y=1.0)
    fig.tight_layout()
    return fig
