"""Normalisation and feature engineering."""
import numpy as np
import pandas as pd
from .parser import SIZE_RE


def size_to_mb(val) -> float:
    """Convert '671 B' / '1,017.25 KB' / '3 MB' / '1.2 GB' to megabytes (binary units: KB/1024, GB*1024)."""
    if val is None or pd.isna(val):
        return np.nan
    m = SIZE_RE.match(str(val).strip())
    if not m:
        return np.nan
    num, unit = float(m.group(1).replace(",", "")), m.group(2).upper()
    return round(num * {"B": 1 / 1024 ** 2, "KB": 1 / 1024, "MB": 1, "GB": 1024}[unit], 4)


def clean(df_raw: pd.DataFrame):
    """Return (cleaned_df, n_duplicates_dropped).

    publication_lag_years = year(lastReleased) - period. NOTE: lastReleased is the
    most recent release, so this is lag to the latest revision, and recent years
    are right-censored.
    """
    df = df_raw.copy()
    df["period"] = pd.to_numeric(df["periods"], errors="coerce").astype("Int64")
    df["fileSize_MB"] = df["fileSize"].apply(size_to_mb)
    df["tarifflineFileSize_MB"] = df["tarifflineFileSize"].apply(size_to_mb)
    df["totalRecords"] = pd.to_numeric(df["totalRecords"], errors="coerce")
    df["tarifflineTotalRecords"] = pd.to_numeric(df["tarifflineTotalRecords"], errors="coerce")
    df["lastReleased_date"] = pd.to_datetime(df["lastReleased"], errors="coerce")
    df["publication_lag_years"] = df["lastReleased_date"].dt.year - df["period"]
    df["classificationCode"] = df["classificationCode"].str.upper().str.strip()
    df["freqCode"] = df["freqCode"].str.upper().str.strip()
    df["reporterDesc"] = df["reporterDesc"].str.strip()
    df = df.drop(columns=["periods", "fileSize", "tarifflineFileSize", "lastReleased"])
    before = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    return df, before - len(df)
