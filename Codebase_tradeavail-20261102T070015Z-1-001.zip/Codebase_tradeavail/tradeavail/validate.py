"""Independent validation of the type-pattern parser.

A row is converted to a token string (S size, D date, I integer, N note artefact, T other text) and must
match a grammar for the optional block. The grammar-derived field assignment is then compared with the
parser output. This is a second decision procedure, not hand-labelled ground truth.
"""
import re
import numpy as np
import pandas as pd
from . import parser as _parser
from .parser import parse_row

TAIL = re.compile(r"^ST(?P<a>ID)?(?P<b>IS?)?(?P<n>N)?T$")  # size,type,[total,date],[tariff count,[tariff size]],[note],desc
CLS = re.compile(r"^[HS]\d$")


# Deliberately LOOSER than the parser's patterns and defined independently of them, so that a
# too-strict parser pattern (e.g. one that rejects "1,017.25 KB") is caught as a disagreement.
_S = re.compile(r"(?i)^[\d.,]+\s*(B|KB|MB|GB|TB)$")
_D = re.compile(r"^\d{4}-\d{2}-\d{2}")
_I = re.compile(r"^[\d,]+$")


def token(v: str) -> str:
    if _S.match(v): return "S"
    if _D.match(v): return "D"
    if _I.match(v): return "I"
    if v.startswith("[object"): return "N"
    return "T"


def grammar_assign(row):
    """Return a dict of the fields the grammar implies, or None if the row violates the grammar."""
    if len(row) < 8 or not re.match(r"^\d{4}$", row[1]) or not CLS.match(row[3].upper()) or row[4].upper() not in ("A", "M"):
        return None
    toks = "".join(token(v) for v in row[5:])
    m = TAIL.match(toks)
    if not m: return None
    vals = row[5:]; i = 2; out = dict(fileSize=vals[0], typeCode=vals[1], totalRecords=None, lastReleased=None,
                                       tarifflineTotalRecords=None, tarifflineFileSize=None, publicationNotes=None)
    if m.group("a"): out["totalRecords"], out["lastReleased"] = vals[i], vals[i + 1]; i += 2
    if m.group("b"):
        out["tarifflineTotalRecords"] = vals[i]; i += 1
        if m.group("b") == "IS": out["tarifflineFileSize"] = vals[i]; i += 1
    if m.group("n"): out["publicationNotes"] = vals[i]; i += 1
    out["reporterDesc"] = vals[i]
    return out


def validate_parser(rows, sample=60, seed=0):
    """Grammar conformance, parser-vs-grammar agreement per field, and a reproducible audit sample."""
    fields = ["fileSize", "typeCode", "totalRecords", "lastReleased", "tarifflineTotalRecords", "tarifflineFileSize", "publicationNotes", "reporterDesc"]
    n_ok = n_agree = 0; field_dis = {f: 0 for f in fields}; bad = []
    for r in rows:
        g = grammar_assign(r); p = parse_row(r)
        if g is None: bad.append(r); continue
        n_ok += 1; dis = [f for f in fields if (g[f] or None) != (p[f] or None)]
        for f in dis: field_dis[f] += 1
        n_agree += not dis
    rng = np.random.default_rng(seed); idx = rng.choice(len(rows), size=min(sample, len(rows)), replace=False)
    audit = pd.DataFrame([{"row_index": int(i), "raw_cells": " | ".join(rows[i]), **{k: v for k, v in parse_row(rows[i]).items() if k not in ("reporterCode", "periods", "reporters", "classificationCode", "freqCode")}} for i in sorted(idx)])
    return {"n_rows": len(rows), "grammar_conforming": n_ok, "grammar_violations": len(bad), "parser_grammar_agreement": n_agree,
            "agreement_rate": n_agree / len(rows), "field_disagreements": field_dis, "violating_rows": bad[:10]}, audit
