"""Statistical analysis: descriptive statistics (with SD), growth model, exposure-adjusted
publication lag, file-size regression with cross-validated and temporal-holdout evaluation.

Design notes
------------
* ``lastReleased`` is the MOST RECENT release, so lag = year(lastReleased) - period grows with the
  time a cohort has been exposed to revision. The maximum possible lag for a reference year is
  ``export_year - period``. We therefore analyse ``lag_ratio = lag / (export_year - period)``.
  Kaplan-Meier is deliberately NOT used: every record with a release date has an observed value,
  so there is no censored event time in the survival sense.
* Success thresholds are reported next to results; they were chosen as reasonable bars, not pre-registered.
"""
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import KFold

EXPORT_YEAR = 2026
NUMERIC = ["fileSize_MB", "totalRecords", "tarifflineTotalRecords", "tarifflineFileSize_MB", "publication_lag_years"]


def describe(df: pd.DataFrame) -> pd.DataFrame:
    """Mean, SD, quartiles, range and skewness for the numeric columns."""
    rows = []
    for c in NUMERIC:
        x = df[c].dropna().astype(float)
        rows.append(dict(column=c, n=len(x), mean=x.mean(), sd=x.std(), median=x.median(),
                         q1=x.quantile(.25), q3=x.quantile(.75), min=x.min(), max=x.max(), skew=stats.skew(x)))
    return pd.DataFrame(rows).set_index("column")


def with_bytes_per_record(df: pd.DataFrame) -> pd.DataFrame:
    d = df.dropna(subset=["totalRecords", "fileSize_MB"]).copy()
    d = d[d.totalRecords > 0]
    d["bytes_per_record"] = d.fileSize_MB * 1024 ** 2 / d.totalRecords
    return d


def tukey_outliers(x: pd.Series, k: float = 1.5) -> pd.Series:
    q1, q3 = x.quantile(.25), x.quantile(.75)
    return (x < q1 - k * (q3 - q1)) | (x > q3 + k * (q3 - q1))


def outlier_report(df: pd.DataFrame) -> dict:
    """Flag (do not drop) Tukey outliers of bytes-per-record within each decade."""
    d = with_bytes_per_record(df)
    d["decade"] = d.period // 10 * 10
    flag = d.groupby("decade", group_keys=False).bytes_per_record.apply(tukey_outliers)
    return {"n_checked": int(len(d)), "n_outliers": int(flag.sum()), "share": round(float(flag.mean()), 4),
            "max_bytes_per_record": float(d.bytes_per_record.max()), "policy": "flagged, retained"}


def growth_model(yearly: pd.Series) -> dict:
    """Log-linear fit ln(records) = a + b*year; CAGR = exp(b)-1 with a 95% CI from the slope."""
    x = yearly.index.to_numpy(dtype=float); y = np.log(yearly.to_numpy(dtype=float))
    r = stats.linregress(x, y); t = stats.t.ppf(.975, len(x) - 2)
    f = lambda b: float(np.expm1(b))
    return {"years": (int(x.min()), int(x.max())), "cagr": f(r.slope), "cagr_ci95": (f(r.slope - t * r.stderr), f(r.slope + t * r.stderr)),
            "r2": float(r.rvalue ** 2), "fold_change": float(yearly.iloc[-1] / yearly.iloc[0])}


def bytes_per_record_test(df: pd.DataFrame, split_year: int = 2010) -> dict:
    """Mann-Whitney U: bytes per record before vs from `split_year`; rank-biserial effect size."""
    d = with_bytes_per_record(df)
    a, b = d[d.period < split_year].bytes_per_record, d[d.period >= split_year].bytes_per_record
    u = stats.mannwhitneyu(a, b, alternative="two-sided")
    return {"split_year": split_year, "n_before": len(a), "n_after": len(b), "median_before": float(a.median()),
            "median_after": float(b.median()), "sd_before": float(a.std()), "sd_after": float(b.std()),
            "U": float(u.statistic), "p": float(u.pvalue), "rank_biserial": float(2 * u.statistic / (len(a) * len(b)) - 1)}


def lag_exposure_analysis(df, export_year=EXPORT_YEAR, min_window=5, seed=0, n_boot=2000, min_group=30) -> dict:
    """Exposure-adjusted lag. Returns raw vs adjusted Spearman and a Kruskal-Wallis test across HS editions."""
    l = df.dropna(subset=["publication_lag_years"]).copy()
    l["window"] = export_year - l.period
    l["lag_ratio"] = l.publication_lag_years / l.window
    violations = int((l.publication_lag_years > l.window).sum())
    raw = stats.spearmanr(l.period, l.publication_lag_years)
    s = l[l.window >= min_window]
    adj = stats.spearmanr(s.period, s.lag_ratio)
    eds = [c for c in sorted(s.classificationCode.unique()) if c.startswith("H") and (s.classificationCode == c).sum() >= min_group]
    groups = [s[s.classificationCode == c].lag_ratio.to_numpy() for c in eds]
    kw = stats.kruskal(*groups); n = sum(len(g) for g in groups)
    rng = np.random.default_rng(seed); rows = []
    for c, g in zip(eds, groups):
        boots = np.median(rng.choice(g, size=(n_boot, len(g)), replace=True), axis=1)
        rows.append(dict(edition=c, n=len(g), median_ratio=float(np.median(g)), ci_lo=float(np.percentile(boots, 2.5)),
                         ci_hi=float(np.percentile(boots, 97.5)), median_lag_years=float(s[s.classificationCode == c].publication_lag_years.median())))
    return {"n_all": len(l), "n_adjusted": len(s), "window_violations": violations,
            "spearman_raw": (float(raw.statistic), float(raw.pvalue)), "spearman_adjusted": (float(adj.statistic), float(adj.pvalue)),
            "kruskal_H": float(kw.statistic), "kruskal_p": float(kw.pvalue), "epsilon_sq": float(kw.statistic / (n - 1)),
            "editions": pd.DataFrame(rows).set_index("edition")}


def _metrics(y, p):
    rmse = float(np.sqrt(np.mean((y - p) ** 2)))
    r2 = float(1 - np.sum((y - p) ** 2) / np.sum((y - y.mean()) ** 2))
    mdape = float(np.median(np.abs(10 ** p - 10 ** y) / 10 ** y))
    return {"rmse_log10": rmse, "r2": r2, "mdape": mdape}


def size_model(df: pd.DataFrame, seed=0, split_year=2010, folds=5) -> dict:
    """log10(file size MB) ~ log10(total records) [+ period]. 5-fold CV and a temporal holdout."""
    d = with_bytes_per_record(df).reset_index(drop=True)
    y = np.log10(d.fileSize_MB.to_numpy()); xa = np.log10(d.totalRecords.to_numpy())[:, None]
    xb = np.column_stack([xa[:, 0], d.period.to_numpy() - 2000.0])
    full = LinearRegression().fit(xa, y)
    cv = {"A": [], "base": []}; pred_cv = np.zeros_like(y); base_cv = np.zeros_like(y)
    for tr, te in KFold(folds, shuffle=True, random_state=seed).split(xa):
        pred_cv[te] = LinearRegression().fit(xa[tr], y[tr]).predict(xa[te]); base_cv[te] = y[tr].mean()
    tr = (d.period <= split_year).to_numpy(); te = ~tr
    out = {"n": len(d), "slope_loglog": float(full.coef_[0]), "intercept": float(full.intercept_),
           "r2_in_sample": float(full.score(xa, y)), "cv5_model": _metrics(y, pred_cv), "cv5_baseline": _metrics(y, base_cv),
           "holdout": {"train_n": int(tr.sum()), "test_n": int(te.sum()), "split_year": split_year}}
    ma = LinearRegression().fit(xa[tr], y[tr]); mb = LinearRegression().fit(xb[tr], y[tr])
    out["holdout"]["A_records_only"] = _metrics(y[te], ma.predict(xa[te]))
    out["holdout"]["B_records_plus_period"] = _metrics(y[te], mb.predict(xb[te]))
    out["holdout"]["baseline_mean"] = _metrics(y[te], np.full(te.sum(), y[tr].mean()))
    out["_frame"] = d.assign(pred_cv=pred_cv, log_size=y, log_records=xa[:, 0])
    return out


def save_stats_figures(df, res, outdir):
    import os, matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt, seaborn as sns
    sns.set_theme(style="whitegrid"); os.makedirs(outdir, exist_ok=True); paths = {}
    d = with_bytes_per_record(df); d["decade"] = (d.period // 10 * 10).astype(int)
    fig, ax = plt.subplots(figsize=(8, 4.5)); sns.boxplot(data=d, x="decade", y="bytes_per_record", color="#8fbfe0", ax=ax, fliersize=2)
    ax.set_ylim(0, d.bytes_per_record.quantile(.995)); ax.set_xlabel("Decade"); ax.set_ylabel("Bytes per record")
    ax.set_title("File size per record is ~13 bytes until the 2000s, then rises"); p = f"{outdir}/bytes_per_record.png"; fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig); paths["bytes_per_record"] = p
    f = res["size_model"]["_frame"]; fig, ax = plt.subplots(figsize=(7, 5))
    sc = ax.scatter(f.log_records, f.log_size, c=f.period, s=6, cmap="viridis", alpha=.6)
    xs = np.linspace(f.log_records.min(), f.log_records.max(), 50); m = res["size_model"]
    ax.plot(xs, m["intercept"] + m["slope_loglog"] * xs, color="crimson", lw=2, label=f"fit: slope {m['slope_loglog']:.2f}, R$^2$ {m['r2_in_sample']:.3f}")
    ax.set_xlabel("log10(total records)"); ax.set_ylabel("log10(file size, MB)"); ax.legend(); plt.colorbar(sc, label="Reference year")
    ax.set_title("File size vs record count (log-log)"); p = f"{outdir}/size_model.png"; fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig); paths["size_model"] = p
    e = res["lag"]["editions"].reset_index(); fig, ax = plt.subplots(figsize=(7, 4.2))
    ax.errorbar(e.edition, e.median_ratio, yerr=[e.median_ratio - e.ci_lo, e.ci_hi - e.median_ratio], fmt="o", capsize=4, color="#2a6f97")
    ax.set_ylabel("Median lag / available window"); ax.set_xlabel("HS edition (reference years with >= 5-year window)")
    ax.set_title("Exposure-adjusted lag by HS edition (95% bootstrap CI)"); p = f"{outdir}/lag_by_edition.png"; fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig); paths["lag_by_edition"] = p
    return paths
