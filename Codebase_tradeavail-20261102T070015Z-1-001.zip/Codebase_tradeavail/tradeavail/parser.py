"""Type-pattern reconstruction parser for the ragged Comtrade availability export.

The raw file is Latin-1 (not UTF-8) and rows contain 9-14 fields instead of the
13 declared in the header, because inapplicable optional fields are omitted
rather than left empty. Fields are therefore assigned by the *type* of each
value, not by position.
"""
from __future__ import annotations
import csv
import re
from collections import Counter
from typing import Dict, List, Optional

import pandas as pd

# Sizes may use thousands separators ("1,017.25 KB") and the byte unit ("671.00 B").
SIZE_RE = re.compile(r"^(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)\s*(B|KB|MB|GB)$", re.I)
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
INT_RE = re.compile(r"^\d+$")

COLUMNS = ["reporterCode", "periods", "reporters", "classificationCode", "freqCode",
           "fileSize", "typeCode", "totalRecords", "lastReleased",
           "tarifflineTotalRecords", "tarifflineFileSize", "publicationNotes",
           "reporterDesc"]


def read_raw(path: str, encoding: str = "latin1"):
    """Return (header, data_rows) using the csv module (ragged rows allowed)."""
    with open(path, encoding=encoding, newline="") as f:
        rows = list(csv.reader(f))
    return rows[0], rows[1:]


def read_xlsx(path: str, sheet=0):
    """Read the Excel version of the export into (header, data_rows).

    Values are read as text. Cells are left-aligned per row (missing optional fields are
    shifted out, trailing cells are blank), so each row is the list of its non-empty cells.
    Datetime cells are converted to ISO dates (YYYY-MM-DD) so the date pattern matches.
    """
    df = pd.read_excel(path, sheet_name=sheet, dtype=str, header=0)
    header = list(df.columns)
    rows = []
    for rec in df.itertuples(index=False, name=None):
        vals = []
        for v in rec:
            if v is None or (isinstance(v, float) and pd.isna(v)) or str(v).strip() == "" or str(v) == "nan":
                continue
            v = str(v).strip()
            if re.match(r"^\d{4}-\d{2}-\d{2} 00:00:00$", v):
                v = v[:10]
            vals.append(v)
        rows.append(vals)
    return header, rows


def read_any(path: str):
    """Dispatch on extension: .xlsx/.xls -> read_xlsx, otherwise read_raw (Latin-1 CSV)."""
    return read_xlsx(path) if path.lower().endswith((".xlsx", ".xls")) else read_raw(path)


def row_width_distribution(rows) -> Dict[int, int]:
    """Number of rows per field-count (diagnostic for the ragged structure)."""
    return dict(sorted(Counter(len(r) for r in rows).items()))


def parse_row(r: List[str]) -> Optional[dict]:
    """Rebuild one record. Returns None if the row has fewer than 5 fields."""
    r = list(r)
    while r and r[-1] == "":
        r.pop()
    if len(r) < 5:
        return None

    out = {"reporterCode": r[0], "periods": r[1], "reporters": r[2],
           "classificationCode": r[3], "freqCode": r[4]}

    idx = 5
    out["fileSize"] = r[idx] if idx < len(r) and SIZE_RE.match(r[idx]) else None
    if out["fileSize"] is not None:
        idx += 1
    out["typeCode"] = r[idx] if idx < len(r) else None
    if out["typeCode"] is not None:
        idx += 1

    reporter_desc = r[-1]
    middle = r[idx:-1]

    out.update(totalRecords=None, lastReleased=None, tarifflineTotalRecords=None,
               tarifflineFileSize=None, publicationNotes=None)

    ints_found = []
    for m in middle:
        if DATE_RE.match(m):
            out["lastReleased"] = m
        elif SIZE_RE.match(m):
            out["tarifflineFileSize"] = m
        elif INT_RE.match(m):
            ints_found.append(m)
        else:
            out["publicationNotes"] = m
    # Known ambiguity: a lone integer is assigned to totalRecords.
    if ints_found:
        out["totalRecords"] = ints_found[0]
    if len(ints_found) >= 2:
        out["tarifflineTotalRecords"] = ints_found[1]

    out["reporterDesc"] = reporter_desc
    return out


def reconstruct(rows) -> pd.DataFrame:
    """Parse all rows; rows that cannot be parsed are skipped (count is reported by caller)."""
    parsed = [p for p in (parse_row(r) for r in rows) if p is not None]
    return pd.DataFrame(parsed)
