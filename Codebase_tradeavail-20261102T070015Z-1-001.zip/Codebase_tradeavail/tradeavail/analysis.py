"""Exploratory analysis helpers (mirrors the original notebook, plus tie-aware reporter coverage)."""
import os
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns

NUM_COLS = ["fileSize_MB", "totalRecords", "tarifflineTotalRecords",
            "tarifflineFileSize_MB", "publication_lag_years", "period"]


def missing_summary(df):
    miss = df.isna().sum().sort_values(ascending=False)
    return pd.DataFrame({"missing_count": miss, "missing_pct": (miss / len(df) * 100).round(1)})


def yearly_records(df):
    return df.dropna(subset=["totalRecords"]).groupby("period")["totalRecords"].sum()


def lag_series(df, lo=0, hi=20):
    lag = df["publication_lag_years"].dropna()
    return lag[(lag >= lo) & (lag <= hi)]


def reporter_coverage(df, k=15):
    """Top-k reporters by record count, plus how many reporters tie at the maximum.

    Ties make a 'top-k' ordering arbitrary, so rankings should not be read as concentration.
    """
    vc = df["reporterDesc"].value_counts()
    return vc.head(k), int((vc == vc.iloc[0]).sum())


def correlations(df):
    return df[NUM_COLS].corr()


def save_all_figures(df, outdir):
    """Write the standard figure set as PNGs into outdir; returns {name: path}."""
    matplotlib.use("Agg")
    sns.set_theme(style="whitegrid", palette="viridis")
    os.makedirs(outdir, exist_ok=True)
    paths = {}

    def _save(fig, name):
        p = os.path.join(outdir, name)
        fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig); paths[name] = p

    m = df.drop(columns=["reporterCode", "reporters"]).isna()
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.imshow(m.to_numpy(dtype=float), aspect="auto", cmap="viridis", interpolation="nearest")
    ax.set_xticks(range(len(m.columns))); ax.set_xticklabels(m.columns, rotation=90); ax.set_yticks([])
    ax.set_title("Missing Value Pattern (yellow = missing)"); _save(fig, "missingness.png")

    cy = (df.dropna(subset=["classificationCode", "period"]).groupby(["period", "classificationCode"]).size()
          .reset_index(name="count").pivot(index="period", columns="classificationCode", values="count").fillna(0))
    fig, ax = plt.subplots(figsize=(12, 6)); cy.plot(kind="area", stacked=True, ax=ax, colormap="tab20", linewidth=0)
    ax.set_title("Records per Year by Classification"); ax.set_xlabel("Year"); ax.set_ylabel("Number of records")
    ax.legend(title="Classification", bbox_to_anchor=(1.02, 1), loc="upper left"); _save(fig, "classification_over_time.png")

    st = df.dropna(subset=["fileSize_MB"]).groupby("period")["fileSize_MB"].mean()
    fig, ax = plt.subplots(figsize=(11, 5)); st.plot(ax=ax, marker="o", markersize=3)
    ax.set_title("Average File Size per Year (MB)"); ax.set_xlabel("Year"); ax.set_ylabel("Average file size (MB)"); _save(fig, "file_size_trend.png")

    rt = yearly_records(df)
    fig, ax = plt.subplots(figsize=(11, 5)); rt.plot(ax=ax, color="#d62728", marker="o", markersize=3)
    ax.ticklabel_format(style="plain", axis="y"); ax.set_title("Total Records per Year"); ax.set_xlabel("Year"); ax.set_ylabel("Total records"); _save(fig, "records_trend.png")

    fig, ax = plt.subplots(figsize=(9, 5)); sns.histplot(lag_series(df), bins=20, kde=True, color="#2ca02c", ax=ax)
    ax.set_title("Publication Lag (years)"); ax.set_xlabel("Publication lag (years)"); ax.set_ylabel("Frequency"); _save(fig, "publication_lag.png")

    fig, ax = plt.subplots(figsize=(7, 6)); sns.heatmap(correlations(df), annot=True, fmt=".2f", cmap="coolwarm", center=0, ax=ax)
    ax.set_title("Correlation Matrix"); _save(fig, "correlation.png")

    from .oml_omh import plot_oml, plot_omh
    yrs, vals = rt.index.to_numpy(dtype=int), rt.to_numpy(dtype=float)
    fig, ax = plt.subplots(figsize=(12, 6))
    plot_oml(yrs, vals, title="Order-of-Magnitude Line (OML): Total Records per Year", ax=ax); _save(fig, "oml.png")
    _save(plot_omh(yrs, vals, title="Order-of-Magnitude Horizon (OMH): Total Records per Year"), "omh.png")
    return paths
