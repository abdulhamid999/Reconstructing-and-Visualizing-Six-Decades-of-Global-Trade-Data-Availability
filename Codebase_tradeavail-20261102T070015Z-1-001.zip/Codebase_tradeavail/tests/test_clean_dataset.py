"""Regression test: headline numbers of the cleaned dataset (skipped if the CSV is absent)."""
import os
import pandas as pd
import pytest
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "comtrade_availability_clean.csv")
pytestmark = pytest.mark.skipif(not os.path.exists(P), reason="cleaned CSV not present")


def test_headline_numbers():
    df = pd.read_csv(P, encoding="utf-8-sig", dtype={"reporters": str})
    assert df.shape == (8916, 14) and df.reporterDesc.nunique() == 235
    assert (df.period.min(), df.period.max()) == (1962, 2025)
    assert set(df.typeCode) == {"C"} and set(df.freqCode) == {"A"} and df.fileSize_MB.notna().all()
    assert sorted(df.classificationCode.unique()) == ["H0", "H1", "H2", "H3", "H4", "H5", "H6", "S1", "S2", "S3"]
    yearly = df.dropna(subset=["totalRecords"]).groupby("period").totalRecords.sum()
    assert (yearly.min(), yearly.max()) == (2023961, 210561656)
    assert df.publication_lag_years.median() == 4.0 and df.totalRecords.isna().sum() == 3471
    assert set(df.publicationNotes.dropna().str.replace(",", "").str.replace("[object Object]", "")) == {""}
