"""Headless dashboard test (skipped if streamlit or the cleaned CSV is unavailable)."""
import os, sys
import pytest
st_testing = pytest.importorskip("streamlit.testing.v1")
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
DATA = [p for p in (os.path.join(ROOT, "data", "comtrade_availability_clean.csv"), os.environ.get("CLEAN_CSV", "")) if p and os.path.exists(p)]


@pytest.mark.skipif(not DATA, reason="cleaned CSV not present")
def test_dashboard_runs_without_exception(monkeypatch):
    monkeypatch.chdir(ROOT)
    at = st_testing.AppTest.from_file(os.path.join(ROOT, "app", "dashboard.py"), default_timeout=60).run()
    assert not at.exception
    assert len(at.metric) == 4 and len(at.tabs) == 4
    at.sidebar.multiselect[1].set_value(["France"]).run()  # filter to one reporter
    assert not at.exception
