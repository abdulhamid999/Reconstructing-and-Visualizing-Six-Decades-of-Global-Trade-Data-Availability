"""Tests use SYNTHETIC rows written to follow the parser's rules.
They verify parsing/cleaning logic, not real Comtrade values."""
import os, sys, tempfile
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from tradeavail import parse_row, size_to_mb, clean, reconstruct, mantissa_exponent, oml_positions
from tradeavail.parser import read_raw, read_xlsx

FULL = ["004", "2020", "Afghanistan", "h5", "a", "1.5 MB", "C", "1200", "2022-03-10",
        "800", "300 KB", "note", "Afghanistan"]


def test_full_row():
    p = parse_row(FULL)
    assert p["fileSize"] == "1.5 MB" and p["typeCode"] == "C"
    assert p["totalRecords"] == "1200" and p["tarifflineTotalRecords"] == "800"
    assert p["lastReleased"] == "2022-03-10" and p["tarifflineFileSize"] == "300 KB"
    assert p["publicationNotes"] == "note" and p["reporterDesc"] == "Afghanistan"


def test_trailing_empty_fields_are_stripped():
    p = parse_row(FULL + ["", ""])
    assert p["reporterDesc"] == "Afghanistan"


def test_short_row_dropped():
    assert parse_row(["1", "2", "3"]) is None


def test_non_numeric_text_goes_to_notes_not_numbers():
    row = FULL[:11] + ["[object Object]"] + FULL[12:]
    p = parse_row(row)
    assert p["publicationNotes"] == "[object Object]"
    assert p["tarifflineTotalRecords"] == "800" and p["totalRecords"] == "1200"


def test_lone_integer_ambiguity_is_documented_behaviour():
    row = FULL[:7] + ["800"] + FULL[-1:]
    assert parse_row(row)["totalRecords"] == "800"  # known ambiguity: assigned to totalRecords


def test_size_to_mb():
    assert size_to_mb("1024 KB") == 1.0 and size_to_mb("2 GB") == 2048.0 and np.isnan(size_to_mb("bad"))


def test_clean_lag_and_duplicates():
    df, dup = clean(reconstruct([FULL, FULL]))
    assert dup == 1 and len(df) == 1
    assert df.loc[0, "classificationCode"] == "H5" and df.loc[0, "publication_lag_years"] == 2
    assert abs(df.loc[0, "tarifflineFileSize_MB"] - 300 / 1024) < 1e-3


def test_mantissa_exponent_and_positions():
    m, e = mantissa_exponent([2_023_961, 210_561_656])
    assert list(e) == [6, 8] and m.min() >= 1 and m.max() < 10
    _, _, y, e_min, e_max = oml_positions([2_023_961, 15_000_000, 210_561_656])
    assert (e_min, e_max) == (6, 8) and abs(y[-1] - (2 + (2.10561656 - 1) / 9)) < 1e-9


def test_latin1_read():
    p = os.path.join(tempfile.mkdtemp(), "x.csv")
    with open(p, "wb") as f:
        f.write("h1,h2,h3\n004,2020,C\xf4te d'Ivoire\n".encode("latin1"))
    header, rows = read_raw(p)
    assert header == ["h1", "h2", "h3"] and "C\u00f4te" in rows[0][2]


def test_thousands_separator_and_byte_units():
    assert size_to_mb("1,017.25 KB") == round(1017.25 / 1024, 4)
    assert abs(size_to_mb("671.00 B") - 671 / 1024 ** 2) < 1e-4  # sizes are rounded to 4 d.p.
    row = FULL[:5] + ["1,017.25 KB", "C", "1200", "2022-03-10", "800", "1,100.50 KB", "note", "Afghanistan"]
    p = parse_row(row)
    assert p["fileSize"] == "1,017.25 KB" and p["typeCode"] == "C" and p["tarifflineFileSize"] == "1,100.50 KB"


def test_read_xlsx_left_aligned_rows_and_datetime_cells():
    import openpyxl, datetime
    d = tempfile.mkdtemp(); path = os.path.join(d, "x.xlsx")
    wb = openpyxl.Workbook(); ws = wb.active
    ws.append(["reporterCode", "periods", "reporters", "classificationCode", "freqCode", "fileSize", "typeCode",
               "totalRecords", "lastReleased", "tarifflineTotalRecords", "tarifflineFileSize", "publicationNotes", "reporterDesc"])
    ws.append([100, 2012, "100", "H4", "A", "2.38 MB", "C", 177516, datetime.datetime(2021, 2, 22), 1008307, "16.82 MB", "[object Object]", "Bulgaria"])
    ws.append([100, 1992, "100", "S3", "A", "534.15 KB", "C", "Bulgaria"])
    wb.save(path)
    header, rows = read_xlsx(path)
    assert len(header) == 13 and rows[1] == ["100", "1992", "100", "S3", "A", "534.15 KB", "C", "Bulgaria"]
    df, _ = clean(reconstruct(rows))
    assert df.loc[0, "publication_lag_years"] == 9 and df.loc[0, "totalRecords"] == 177516
    assert df.loc[1, "totalRecords"] != df.loc[1, "totalRecords"]  # NaN: no release metadata


def test_validator_agrees_on_good_rows_and_would_catch_the_original_size_bug(monkeypatch):
    import re
    from tradeavail import parser
    from tradeavail.validate import validate_parser
    base = FULL[:11] + ["[object Object]", "Afghanistan"]  # real notes are always the upstream artefact string
    rows = [base, FULL[:5] + ["1,017.25 KB", "C", "1200", "2022-03-10", "800", "1,100.50 KB", "[object Object]", "Afghanistan"]]
    ok, _ = validate_parser(rows, sample=2)
    assert ok["agreement_rate"] == 1.0
    old = re.compile(r"^(\d+(?:\.\d+)?)\s*(KB|MB|GB)$", re.I)  # the notebook's original pattern
    monkeypatch.setattr(parser, "SIZE_RE", old)
    bad, _ = validate_parser(rows, sample=2)
    assert bad["agreement_rate"] < 1.0  # the independent grammar flags the mis-parsed row
