#!/usr/bin/env python3
"""End-to-end pipeline: raw Comtrade availability CSV -> cleaned CSV + figures + summary.json

Usage:
    python scripts/run_pipeline.py --raw data/trade_data_availability.csv --out outputs
"""
import argparse, json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from tradeavail import read_any, reconstruct, row_width_distribution, clean
from tradeavail import analysis as A


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True, help="raw availability export: .xlsx or Latin-1 .csv")
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--no-figures", action="store_true")
    a = ap.parse_args()

    os.makedirs(a.out, exist_ok=True)
    header, rows = read_any(a.raw)
    widths = row_width_distribution(rows)
    df_raw = reconstruct(rows)
    df, n_dup = clean(df_raw)
    df.to_csv(os.path.join(a.out, "comtrade_availability_clean.csv"), index=False)

    rt = A.yearly_records(df)
    lag = A.lag_series(df)
    top, n_tied = A.reporter_coverage(df)
    summary = {
        "header_columns": len(header), "raw_rows": len(rows), "row_width_distribution": widths,
        "reconstructed_rows": int(len(df_raw)), "duplicates_dropped": int(n_dup),
        "clean_shape": list(df.shape), "reporters": int(df["reporterDesc"].nunique()),
        "year_min": int(df["period"].min()), "year_max": int(df["period"].max()),
        "classifications": sorted(df["classificationCode"].dropna().unique().tolist()),
        "freq_codes": sorted(df["freqCode"].dropna().unique().tolist()),
        "yearly_records_min": float(rt.min()), "yearly_records_max": float(rt.max()),
        "lag_median": float(lag.median()), "lag_mean": round(float(lag.mean()), 2),
        "top_reporters_tied_at_max": n_tied,
        "missing": A.missing_summary(df)["missing_count"].astype(int).to_dict(),
    }
    json.dump(summary, open(os.path.join(a.out, "summary.json"), "w"), indent=2)
    A.missing_summary(df).to_csv(os.path.join(a.out, "missing_summary.csv"))
    if not a.no_figures:
        A.save_all_figures(df, os.path.join(a.out, "figures"))
    print(json.dumps({k: summary[k] for k in ("raw_rows", "reconstructed_rows", "duplicates_dropped", "clean_shape")}, indent=2))


if __name__ == "__main__":
    main()
