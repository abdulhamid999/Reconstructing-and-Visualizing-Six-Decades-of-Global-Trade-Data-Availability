#!/usr/bin/env python3
"""Statistics + validation. Usage: python scripts/run_stats.py --raw data/DataAvailability_*.xlsx --out outputs"""
import argparse, json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from tradeavail import read_any, reconstruct, clean
from tradeavail import stats as S, analysis as A
from tradeavail.validate import validate_parser


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--raw", required=True); ap.add_argument("--out", default="outputs")
    ap.add_argument("--export-year", type=int, default=S.EXPORT_YEAR); a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    header, rows = read_any(a.raw); df, _ = clean(reconstruct(rows))
    val, audit = validate_parser(rows); audit.to_csv(os.path.join(a.out, "parser_audit_sample.csv"), index=False)
    yearly = A.yearly_records(df)
    res = {"describe": S.describe(df), "outliers": S.outlier_report(df), "growth": S.growth_model(yearly),
           "bytes_per_record_test": S.bytes_per_record_test(df), "lag": S.lag_exposure_analysis(df, export_year=a.export_year),
           "size_model": S.size_model(df)}
    S.describe(df).round(3).to_csv(os.path.join(a.out, "descriptive_stats.csv"))
    res["lag"]["editions"].round(4).to_csv(os.path.join(a.out, "lag_by_edition.csv"))
    figs = S.save_stats_figures(df, res, os.path.join(a.out, "figures"))
    ser = {k: (v.round(4).to_dict("index") if hasattr(v, "to_dict") else v) for k, v in res.items()}
    ser["lag"] = {k: (v.round(4).to_dict("index") if hasattr(v, "to_dict") else v) for k, v in res["lag"].items()}
    ser["size_model"] = {k: v for k, v in res["size_model"].items() if k != "_frame"}; ser["describe"] = res["describe"].round(3).to_dict("index")
    ser["parser_validation"] = val
    json.dump(ser, open(os.path.join(a.out, "stats_summary.json"), "w"), indent=2, default=str)
    print(json.dumps({"parser_validation": {k: v for k, v in val.items() if k != "violating_rows"}}, indent=2, default=str))

if __name__ == "__main__":
    main()
