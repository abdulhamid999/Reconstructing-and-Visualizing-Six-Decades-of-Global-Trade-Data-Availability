# Problem statement and objectives

## Context
UN Comtrade publishes trade *values*, but analysts first need to know **what data exist**: which reporter, which
year, which classification, how large, and when last released. That is the *Data Availability* export. It carries
no trade values, it is rarely analysed as a dataset, and its raw form is awkward to load: optional fields are
omitted rather than left blank, so each row is left-shifted (8-13 populated cells instead of 13).

## Analytical questions
| # | Question | Why it matters |
|---|---|---|
| RQ1 | Can the export be reconstructed reliably into a tidy table? | Every later result depends on correct field assignment |
| RQ2 | How did classification regimes, reporting volume and file size evolve, 1962-2025? | Tells analysts which edition covers which period and how data grew |
| RQ3 | How timely are releases, and can timeliness be compared across eras when only the *last* release date exists? | Timeliness is a core data-quality dimension, but the field is biased by exposure |
| RQ4 | Can file size be predicted from record count, and is that relationship stable over time? | Capacity planning and sanity-checking releases |

## Hypotheses tested
- H1: yearly record totals grow log-linearly (a constant compound rate).
- H2: bytes per record changed after 2010 (null: no change).
- H3: exposure-adjusted lag differs across HS editions (null: no difference).

## Success metrics (bars chosen as reasonable thresholds, not pre-registered)
| Metric | Target | Result |
|---|---|---|
| Rows reconstructed | 100% | 8,916 / 8,916 |
| Agreement with an independent grammar | >= 99% | 100% (0 violations); validator proven to catch the original bug |
| Random manual audit (60 rows, seed 0) | 0 errors | 0 errors (author-reviewed, not an independent annotator) |
| Categorical integrity | `typeCode` single-valued; notes only the upstream artefact | Pass |
| Growth quantified with an interval | CAGR + 95% CI | 12.0% per year (10.9-13.1%), R^2 0.93 |
| Per-record size test with effect size | p-value + effect size | median 13.0 -> 16.5 bytes, rank-biserial -0.54 |
| Size model, temporal holdout (train <= 2010, test > 2010) | R^2 >= 0.95 | 0.973 (records), 0.982 (+ year) |
| Reproducibility | one command regenerates headline numbers; tests pass | `run_pipeline.py`, `run_stats.py`, 14 tests |

## Out of scope
Trade values, economic interpretation of record growth, and causal claims. The export has one source, so there is
no multi-table integration; joining external reference data (e.g. income groups) is listed under next steps.
